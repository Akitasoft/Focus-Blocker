// blocked.js — Focus Wall script

let blockedHref = '';
let blockedDomain = '';

try {
  const params = new URLSearchParams(location.search);
  const src = params.get('src');
  if (src) blockedHref = decodeURIComponent(src);
  if (blockedHref) {
    const u = new URL(blockedHref);
    blockedDomain = u.hostname.replace(/^www\./, '');
    document.getElementById('display-domain').textContent = blockedDomain;
    document.getElementById('display-url').textContent = blockedHref;
  }
} catch(e) {}

const visitBtn  = document.getElementById('visit-btn');
const timerBox  = document.getElementById('timer-box');
const countNote = document.getElementById('countdown-note');

function enableVisit() {
  visitBtn.disabled = false;
  visitBtn.textContent = blockedHref ? 'Visit ' + (blockedDomain || 'Site') : 'Blocker is Off';
  visitBtn.onclick = () => { if (blockedHref) location.href = blockedHref; };
}

function update() {
  chrome.storage.local.get(['focusSession', 'enabled'], (data) => {
    if (!data.enabled) {
      timerBox.textContent = 'The blocker is currently off.';
      timerBox.className = 'timer-box done';
      countNote.textContent = '';
      enableVisit(); return;
    }

    if (!data.focusSession || !data.focusSession.endsAt) {
      timerBox.textContent = 'Focus session active — no time limit.';
      timerBox.className = 'timer-box neutral';
      visitBtn.disabled = true;
      visitBtn.textContent = 'Visit When Unblocked';
      countNote.textContent = 'Turn off Focus Blocker to visit this site.';
      return;
    }

    if (data.focusSession.paused) {
      const r = data.focusSession.remainingMs || 0;
      const m = Math.floor(r / 60000);
      const s = String(Math.floor((r % 60000) / 1000)).padStart(2, '0');
      timerBox.textContent = `Session paused — ${m}:${s} remaining`;
      timerBox.className = 'timer-box neutral';
      visitBtn.disabled = true;
      visitBtn.textContent = 'Visit When Unblocked';
      countNote.textContent = 'Resume or turn off the blocker to visit.';
      return;
    }

    const rem = Math.max(0, data.focusSession.endsAt - Date.now());
    if (rem <= 0) {
      timerBox.textContent = '✓ Your focus session is complete!';
      timerBox.className = 'timer-box done';
      countNote.textContent = '';
      enableVisit();
    } else {
      const m = Math.floor(rem / 60000);
      const s = String(Math.floor((rem % 60000) / 1000)).padStart(2, '0');
      timerBox.textContent = `Session ends in ${m}:${s}`;
      timerBox.className = 'timer-box';
      visitBtn.disabled = true;
      visitBtn.textContent = 'Visit When Unblocked';
      countNote.textContent = 'This button unlocks when your session ends.';
    }
  });
}

update();
setInterval(update, 1000);
