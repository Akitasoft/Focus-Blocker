// popup.js — Focus Blocker

const DEFAULT_CATEGORIES = {
  Social: '#4ade80', Entertainment: '#f472b6', News: '#60a5fa',
  Shopping: '#fb923c', Gaming: '#c084fc'
};
let CATEGORIES = { ...DEFAULT_CATEGORIES };
let selectedCategories = []; // for the add-site tag picker

let state = {
  blocklist: [], enabled: false, focusSession: null, selectedMinutes: 25,
  strictMode: false, passwordHash: null, passwordEnabled: false,
  cooldownUntil: null, cooldownMinutes: 5, cooldownEnabled: false,
  schedule: { enabled: false, days: [1,2,3,4,5], startTime: '09:00', endTime: '17:00' },
  redirectUrl: '', blockAttempts: 0, customCategories: {}, deletedCategories: {}, activeLists: [],
};

let countdownInterval = null;
let pendingToggleAction = null;
let activeCategory = 'All';

// ── Boot ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadState();
  renderAll();
  bindEvents();
  startCountdown();
  loadAttempts();
});

async function loadState() {
  return new Promise(resolve => {
    chrome.storage.local.get(null, (data) => {
      state.blocklist       = (data.blocklist || []).map(b => typeof b === 'string' ? { domain: b, categories: [] } : b);
      state.enabled         = data.enabled || false;
      state.focusSession    = data.focusSession || null;
      state.strictMode      = data.strictMode || false;
      state.passwordHash    = data.passwordHash || null;
      state.passwordEnabled = data.passwordEnabled || false;
      state.cooldownUntil   = data.cooldownUntil || null;
      state.cooldownMinutes = data.cooldownMinutes || 5;
      state.cooldownEnabled = data.cooldownEnabled || false;
      state.schedule        = data.schedule || { enabled: false, days: [1,2,3,4,5], startTime: '09:00', endTime: '17:00' };
      state.redirectUrl     = data.redirectUrl || '';
      state.blockAttempts   = data.blockAttempts || 0;
      state.customCategories  = data.customCategories  || {};
      state.deletedCategories = data.deletedCategories || {};
      state.activeLists       = data.activeLists       || [];
      CATEGORIES = { ...DEFAULT_CATEGORIES, ...state.customCategories };
      resolve();
    });
  });
}

function saveState(rebuildRules = true) {
  chrome.storage.local.set({
    blocklist:        state.blocklist,
    enabled:          state.enabled,
    focusSession:     state.focusSession,
    strictMode:       state.strictMode,
    passwordHash:     state.passwordHash,
    passwordEnabled:  state.passwordEnabled,
    cooldownUntil:    state.cooldownUntil,
    cooldownMinutes:  state.cooldownMinutes,
    cooldownEnabled:  state.cooldownEnabled,
    schedule:         state.schedule,
    redirectUrl:      state.redirectUrl,
    blockAttempts:    state.blockAttempts,
    customCategories: state.customCategories,
    deletedCategories:state.deletedCategories,
    activeLists:      state.activeLists,
  });
  if (rebuildRules) {
    chrome.runtime.sendMessage({
      type: 'REBUILD_RULES',
      blocklist:   state.blocklist,
      enabled:     state.enabled,
      redirectUrl: state.redirectUrl,
      activeLists: state.activeLists,
    });
  }
}

// ── Render ────────────────────────────────────────────────────────────────────
function renderActiveLists() {
  const el       = document.getElementById('activeListsChooser');
  const lockNote = document.getElementById('activeListsLockNote');
  if (!el) return;

  const running = state.enabled;
  const allOn   = state.activeLists.includes('__ALL__');

  if (lockNote) {
    lockNote.textContent = '🔒 Blocker is active — you can add lists but not remove them.';
    lockNote.style.display = running ? 'block' : 'none';
  }

  // Build buttons: "All" first, then each named list
  const entries = [['__ALL__', '#39FF14'], ...Object.entries(CATEGORIES)];

  el.innerHTML = entries.map(([name, color]) => {
    const isAll  = name === '__ALL__';
    const label  = isAll ? 'All' : name;
    const isOn   = isAll ? allOn : state.activeLists.includes(name);
    const bg     = isOn ? color : color + '18';
    const col    = isOn ? '#0a0a0a' : color;
    const bord   = isOn ? 'transparent' : color;

    const count = isAll
      ? state.blocklist.length
      : state.blocklist.filter(b => {
          const cats = Array.isArray(b.categories) ? b.categories : (b.category ? [b.category] : []);
          return cats.includes(name);
        }).length;

    // While running: can toggle ON (enable) but NOT toggle OFF (disable)
    const wouldRemove = running && isOn;
    const disabledStyle = wouldRemove ? 'opacity:0.45;cursor:not-allowed;' : '';
    const disabledAttr  = wouldRemove ? 'disabled' : '';

    return `<button class="tag-option${isOn ? ' selected' : ''}" data-list="${escHtml(name)}"
      style="background:${bg};color:${col};border-color:${bord};font-size:12px;${disabledStyle}"
      ${disabledAttr}
      title="${count} site${count!==1?'s':''}">${escHtml(label)} <span style="opacity:0.7;font-size:10px;">${count}</span></button>`;
  }).join('');

  // Warning when nothing selected
  const warnEl = document.getElementById('activeListsWarn');
  if (warnEl) {
    const noneSelected = state.activeLists.length === 0;
    warnEl.style.display = noneSelected ? 'block' : 'none';
  }

  el.querySelectorAll('.tag-option:not([disabled])').forEach(btn => {
    btn.addEventListener('click', () => {
      const list = btn.dataset.list;

      if (list === '__ALL__') {
        // Toggle All: when turning on, clear individual selections
        if (state.activeLists.includes('__ALL__')) {
          // Only allow turning off when not running
          if (!running) state.activeLists = [];
        } else {
          state.activeLists = ['__ALL__'];
        }
      } else {
        // Individual list
        if (state.activeLists.includes('__ALL__')) {
          // If All is on and we click a specific list, do nothing while running
          if (running) return;
          // When not running: switch from All to just this list
          state.activeLists = [list];
        } else {
          const idx = state.activeLists.indexOf(list);
          if (idx >= 0) {
            if (!running) state.activeLists.splice(idx, 1);
          } else {
            state.activeLists.push(list);
          }
        }
      }

      saveState();
      renderActiveLists();
    });
  });
}

function renderAll() {
  renderHeader();
  renderSessionTab();
  renderActiveLists();
  renderBlocklist();
  renderSchedule();
  renderSettings();
}

function renderHeader() {
  const toggle = document.getElementById('masterToggle');
  const dot    = document.getElementById('statusDot');
  const label  = document.getElementById('statusLabel');
  const paused = state.focusSession && state.focusSession.paused;
  const inCooldown = state.cooldownUntil && Date.now() < state.cooldownUntil;

  toggle.checked = state.enabled;

  // Disable toggle in strict mode during session, or during cooldown
  const lockToggle = (state.enabled && state.strictMode && state.focusSession) || inCooldown;
  toggle.disabled = lockToggle && !state.enabled; // only lock OFF action

  if (state.enabled && paused) {
    dot.className = 'status-dot paused'; label.textContent = 'PAUSED'; label.className = 'status-label paused';
  } else if (state.enabled) {
    dot.className = 'status-dot on'; label.textContent = 'ON'; label.className = 'status-label on';
  } else {
    dot.className = 'status-dot'; label.textContent = 'OFF'; label.className = 'status-label';
  }
}

function renderSessionTab() {
  const paused = state.focusSession && state.focusSession.paused;
  const hasTimer = state.focusSession && state.focusSession.endsAt;
  const inCooldown = state.cooldownUntil && Date.now() < state.cooldownUntil;

  const pauseBtn = document.getElementById('pauseBtn');
  const resetBtn = document.getElementById('resetBtn');

  if (state.enabled && hasTimer) {
    pauseBtn.classList.remove('hidden');
    resetBtn.classList.remove('hidden');
    pauseBtn.textContent = paused ? '▶ Resume' : '⏸ Pause';
  } else {
    pauseBtn.classList.add('hidden');
    resetBtn.classList.add('hidden');
  }

  document.getElementById('strictToggle').checked = state.strictMode;
  document.getElementById('cooldownToggle').checked = state.cooldownEnabled;
  document.getElementById('cooldownMinRow').style.display = state.cooldownEnabled ? 'flex' : 'none';
  document.getElementById('cooldownMinInput').value = state.cooldownMinutes;

  const warning = document.getElementById('cooldownWarning');
  if (inCooldown) {
    const rem = Math.ceil((state.cooldownUntil - Date.now()) / 60000);
    warning.textContent = `Cooldown active — ${rem}m remaining before you can enable`;
    warning.classList.add('show');
  } else {
    warning.classList.remove('show');
  }
}

function getCats(entry) {
  // Normalize: support old single-category and new multi-category
  if (Array.isArray(entry.categories) && entry.categories.length > 0)
    return entry.categories.filter(c => c !== 'Other');
  if (entry.category && entry.category !== 'Other') return [entry.category];
  return [];
}

function renderTagPicker() {
  const picker = document.getElementById('tagPicker');
  const selectedEl = document.getElementById('selectedTags');
  if (!picker || !selectedEl) return;
  picker.innerHTML = Object.entries(CATEGORIES).map(([name, color]) => {
    const isSel = selectedCategories.includes(name);
    return `<button class="tag-option${isSel ? ' selected' : ''}" data-cat="${escHtml(name)}" style="${isSel ? `background:${color};color:#fff;` : `border-color:${color};color:${color};background:${color}15;`}">${escHtml(name)}</button>`;
  }).join('');
  picker.querySelectorAll('.tag-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.dataset.cat;
      const idx = selectedCategories.indexOf(cat);
      if (idx >= 0) selectedCategories.splice(idx, 1);
      else selectedCategories.push(cat);
      renderTagPicker();
    });
  });
  selectedEl.innerHTML = selectedCategories.map(cat => {
    const color = CATEGORIES[cat] || '#6b6b6b';
    return `<span class="selected-tag" style="background:${color}">${escHtml(cat)}</span>`;
  }).join('');
}

function renderBlocklist() {
  const categories = ['All', ...Object.keys(CATEGORIES)];
  const filtersEl = document.getElementById('catFilters');
  filtersEl.innerHTML = categories.map(c => {
    const color = CATEGORIES[c];
    const isActive = c === activeCategory;
    const style = color
      ? (isActive
          ? `background:${color};color:#fff;border-color:${color};`
          : `border-color:${color};color:${color};background:${color}15;`)
      : ''; // All — uses CSS class only
    return `<button class="cat-btn${isActive && !color ? ' active' : ''}" data-cat="${c}" style="${style}">${c}</button>`;
  }).join('');
  filtersEl.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => { activeCategory = btn.dataset.cat; renderBlocklist(); });
  });

  const listEl = document.getElementById('siteList');
  const filtered = activeCategory === 'All'
    ? state.blocklist
    : state.blocklist.filter(b => getCats(b).includes(activeCategory));
  document.getElementById('countBadge').textContent = state.blocklist.length;

  if (filtered.length === 0) {
    listEl.innerHTML = `<div class="empty-state">${activeCategory === 'All' ? 'No sites blocked yet.' : 'None in this category.'}</div>`;
  } else {
    listEl.innerHTML = filtered.map((entry) => {
      const realIdx = state.blocklist.indexOf(entry);
      const cats = getCats(entry);
      const dots = cats.filter(c => CATEGORIES[c]).map(c =>
        `<div class="cat-dot" style="background:${CATEGORIES[c]}"></div>`
      ).join('');
      let display = entry.domain;
      let pathNote = '';
      if (entry.domain.includes('|')) {
        const [d, p] = entry.domain.split('|');
        display = d; pathNote = `<span class="site-path"> (except ${p})</span>`;
      }
      return `<div class="site-item" data-index="${realIdx}" style="cursor:pointer;" title="Click to edit lists">
        <div style="display:flex;gap:3px;flex-shrink:0">${dots}</div>
        <span class="site-name">${escHtml(display)}${pathNote}</span>
        <button class="remove-btn" data-index="${realIdx}" title="Remove">×</button>
      </div>`;
    }).join('');
    listEl.querySelectorAll('.remove-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        state.blocklist.splice(parseInt(btn.dataset.index), 1);
        saveState(); renderBlocklist();
      });
    });
    listEl.querySelectorAll('.site-item').forEach(item => {
      item.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-btn')) return;
        openSiteEdit(parseInt(item.dataset.index));
      });
    });
  }
  renderTagPicker();
}

function renderSchedule() {
  document.getElementById('scheduleToggle').checked = state.schedule.enabled;
  document.querySelectorAll('.day-btn').forEach(btn => {
    const day = parseInt(btn.dataset.day);
    btn.classList.toggle('active', state.schedule.days.includes(day));
  });
  document.getElementById('scheduleStart').value = state.schedule.startTime;
  document.getElementById('scheduleEnd').value   = state.schedule.endTime;
  updateScheduleBadge(state.schedule.enabled);
  // Clock drawn on tab open via startClockTicker
}

function updateScheduleBadge(on) {
  const badge = document.getElementById('scheduleStatusBadge');
  if (!badge) return;
  if (on) {
    badge.textContent = 'Active';
    badge.style.background = 'rgba(57,255,20,0.15)';
    badge.style.color = '#39FF14';
    badge.style.border = '1px solid rgba(57,255,20,0.4)';
  } else {
    badge.textContent = 'Off';
    badge.style.background = 'rgba(255,255,255,0.06)';
    badge.style.color = '#888';
    badge.style.border = '1px solid #3d3d3d';
  }
}

let clockInterval = null;
let _clockStart = '09:00';
let _clockEnd   = '17:00';

function startClockTicker(startStr, endStr) {
  _clockStart = startStr;
  _clockEnd   = endStr;
  if (clockInterval) clearInterval(clockInterval);
  drawScheduleClock(_clockStart, _clockEnd);
  clockInterval = setInterval(() => drawScheduleClock(_clockStart, _clockEnd), 1000);
}

function stopClockTicker() {
  if (clockInterval) { clearInterval(clockInterval); clockInterval = null; }
}

function drawScheduleClock(startStr, endStr) {
  const canvas = document.getElementById('scheduleClock');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  // Fix for high-DPI screens — scale canvas buffer to match device pixel ratio
  const dpr    = window.devicePixelRatio || 1;
  const cssW   = 220;
  const cssH   = 220;
  if (canvas.width !== cssW * dpr || canvas.height !== cssH * dpr) {
    canvas.width  = cssW * dpr;
    canvas.height = cssH * dpr;
    canvas.style.width  = cssW + 'px';
    canvas.style.height = cssH + 'px';
    ctx.scale(dpr, dpr);
  }

  const W = cssW, H = cssH;
  const cx = W / 2, cy = H / 2;
  const R  = W / 2 - 10;

  const faceCol   = '#2e2e2e';
  const borderCol = '#3d3d3d';
  const tickCol   = '#555';
  const textCol   = '#f0f0f0';
  const accentCol = '#60a5fa';
  const accentDim = 'rgba(96,165,250,0.15)';
  const hourHandCol   = '#f0f0f0';
  const minHandCol    = '#f0f0f0';
  const secHandCol    = '#ff5a5a';

  ctx.clearRect(0, 0, W, H);

  // ── Parse schedule times ──────────────────────────────────────────────────
  function parseTime(str) {
    const [h, m] = (str || '00:00').split(':').map(Number);
    return h + m / 60;
  }
  function hourAngle(h24) {
    return ((h24 % 12) / 12) * Math.PI * 2 - Math.PI / 2;
  }

  const startH = parseTime(startStr);
  const endH   = parseTime(endStr);

  // ── Face ──────────────────────────────────────────────────────────────────
  ctx.beginPath();
  ctx.arc(cx, cy, R, 0, Math.PI * 2);
  ctx.fillStyle = faceCol;
  ctx.fill();
  ctx.strokeStyle = borderCol;
  ctx.lineWidth = 2;
  ctx.stroke();

  // ── Schedule arc (blocked window) ─────────────────────────────────────────
  const startAngle = hourAngle(startH);
  const endAngle   = hourAngle(endH);
  const durationH  = ((endH - startH) + 24) % 24;
  const sweep      = Math.min(durationH, 12) / 12 * Math.PI * 2;
  const arcR       = R - 4;

  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.arc(cx, cy, arcR, startAngle, startAngle + sweep, false);
  ctx.closePath();
  ctx.fillStyle = accentDim;
  ctx.fill();

  ctx.beginPath();
  ctx.arc(cx, cy, arcR, startAngle, startAngle + sweep, false);
  ctx.strokeStyle = accentCol;
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // ── Ticks + numbers (all 12 hours) ───────────────────────────────────────
  for (let h = 0; h < 12; h++) {
    const angle   = (h / 12) * Math.PI * 2 - Math.PI / 2;
    const isMajor = h % 3 === 0;
    const tickLen = isMajor ? 10 : 5;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(angle) * (R - 2), cy + Math.sin(angle) * (R - 2));
    ctx.lineTo(cx + Math.cos(angle) * (R - 2 - tickLen), cy + Math.sin(angle) * (R - 2 - tickLen));
    ctx.strokeStyle = isMajor ? textCol : tickCol;
    ctx.lineWidth = isMajor ? 2 : 1;
    ctx.stroke();

    // All hours labelled — smaller font for non-major positions
    const label = h === 0 ? '12' : String(h);
    ctx.fillStyle = isMajor ? textCol : '#aaa';
    ctx.font = isMajor ? '700 11px Inter, sans-serif' : '500 9px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label,
      cx + Math.cos(angle) * (R - 20),
      cy + Math.sin(angle) * (R - 20));
  }

  // ── Schedule start/end marker hands ───────────────────────────────────────
  function drawMarkerHand(angle, color, len) {
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(angle) * len, cy + Math.sin(angle) * len);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.stroke();
  }
  drawMarkerHand(startAngle, accentCol, R * 0.62);
  drawMarkerHand(endAngle,   accentCol, R * 0.62);

  // ── AM/PM labels ──────────────────────────────────────────────────────────
  function fmtAmPm(h24) {
    const h = Math.floor(h24), m = Math.round((h24 - h) * 60);
    return `${h % 12 || 12}:${String(m).padStart(2,'0')} ${h < 12 ? 'AM' : 'PM'}`;
  }
  function drawLabel(angle, text, rFrac) {
    const lx = cx + Math.cos(angle) * (R * rFrac);
    const ly = cy + Math.sin(angle) * (R * rFrac);
    ctx.font = '700 10px Inter, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const lw = ctx.measureText(text).width + 8;
    ctx.fillStyle = 'rgba(96,165,250,0.22)';
    ctx.beginPath(); ctx.roundRect(lx - lw/2, ly - 8, lw, 16, 3); ctx.fill();
    ctx.fillStyle = accentCol;
    ctx.fillText(text, lx, ly);
  }
  // Place labels slightly outside the arc
  const labelR = 0.78;
  drawLabel(startAngle, fmtAmPm(startH), labelR);
  // Offset end label if too close to start
  const angleDiff = Math.abs(((endAngle - startAngle) + Math.PI * 2) % (Math.PI * 2));
  const endLabelR = angleDiff < 0.6 ? 0.70 : labelR;
  drawLabel(endAngle, fmtAmPm(endH), endLabelR);

  // ── Live clock hands — uses local system time ────────────────────────────
  const now  = new Date();
  const secs = now.getSeconds() + now.getMilliseconds() / 1000;
  const mins = now.getMinutes() + secs / 60;
  const hrs  = (now.getHours() % 12) + mins / 60;

  const secAngle  = (secs  / 60)  * Math.PI * 2 - Math.PI / 2;
  const minAngle  = (mins  / 60)  * Math.PI * 2 - Math.PI / 2;
  const hourAngle2= (hrs   / 12)  * Math.PI * 2 - Math.PI / 2;

  // Hour hand — thick, short
  ctx.beginPath();
  ctx.moveTo(cx - Math.cos(hourAngle2) * R * 0.1,
             cy - Math.sin(hourAngle2) * R * 0.1);
  ctx.lineTo(cx + Math.cos(hourAngle2) * R * 0.50,
             cy + Math.sin(hourAngle2) * R * 0.50);
  ctx.strokeStyle = hourHandCol;
  ctx.lineWidth = 5;
  ctx.lineCap = 'round';
  ctx.stroke();

  // Minute hand — medium, longer
  ctx.beginPath();
  ctx.moveTo(cx - Math.cos(minAngle) * R * 0.12,
             cy - Math.sin(minAngle) * R * 0.12);
  ctx.lineTo(cx + Math.cos(minAngle) * R * 0.70,
             cy + Math.sin(minAngle) * R * 0.70);
  ctx.strokeStyle = minHandCol;
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  ctx.stroke();

  // Second hand — thin, red, full length
  ctx.beginPath();
  ctx.moveTo(cx - Math.cos(secAngle) * R * 0.18,
             cy - Math.sin(secAngle) * R * 0.18);
  ctx.lineTo(cx + Math.cos(secAngle) * R * 0.85,
             cy + Math.sin(secAngle) * R * 0.85);
  ctx.strokeStyle = secHandCol;
  ctx.lineWidth = 1.5;
  ctx.lineCap = 'round';
  ctx.stroke();

  // Center cap
  ctx.beginPath();
  ctx.arc(cx, cy, 5, 0, Math.PI * 2);
  ctx.fillStyle = secHandCol;
  ctx.fill();
  ctx.beginPath();
  ctx.arc(cx, cy, 2.5, 0, Math.PI * 2);
  ctx.fillStyle = '#fff';
  ctx.fill();
}

function renderSettings() {
  document.getElementById('passwordToggle').checked = state.passwordEnabled;
  document.getElementById('redirectInput').value = state.redirectUrl;

  // Lock password fields while blocker is active
  const locked = state.enabled;
  const pwInput  = document.getElementById('passwordInput');
  const pwBtn    = document.getElementById('savePasswordBtn');
  const pwNote   = document.getElementById('passwordLockNote');
  const pwToggle = document.getElementById('passwordToggle');
  if (pwInput)  { pwInput.disabled  = locked; pwInput.style.opacity  = locked ? '0.4' : '1'; }
  if (pwBtn)    { pwBtn.disabled    = locked; pwBtn.style.opacity    = locked ? '0.4' : '1'; pwBtn.style.cursor = locked ? 'not-allowed' : 'pointer'; }
  if (pwToggle) { pwToggle.disabled = locked; pwToggle.style.opacity = locked ? '0.5' : '1'; }
  if (pwNote)   { pwNote.style.display = locked ? 'block' : 'none'; }
}


function bindEvents() {
  // Tabs
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
      if (tab.dataset.tab === 'settings') { renderSettings(); }
      if (tab.dataset.tab === 'schedule') startClockTicker(state.schedule.startTime, state.schedule.endTime);
      else stopClockTicker();
    });
  });

  // Master toggle
  document.getElementById('masterToggle').addEventListener('change', (e) => {
    const turningOff = !e.target.checked;
    const inCooldown = state.cooldownUntil && Date.now() < state.cooldownUntil;

    // Block turning off during cooldown
    if (turningOff && inCooldown) {
      e.target.checked = true;
      toast('Cooldown active — wait before disabling');
      return;
    }

    // Block turning off in strict mode
    if (turningOff && state.strictMode && state.focusSession) {
      e.target.checked = true;
      toast('Strict mode: cannot disable during session');
      return;
    }

    // Password check when turning off
    if (turningOff && state.passwordEnabled && state.passwordHash) {
      e.target.checked = true;
      pendingToggleAction = () => doToggle(false);
      showPasswordModal();
      return;
    }

    doToggle(e.target.checked);
  });

  function doToggle(on) {
    state.enabled = on;
    if (on && state.selectedMinutes > 0) {
      const endsAt = Date.now() + state.selectedMinutes * 60 * 1000;
      state.focusSession = { endsAt, paused: false };
      chrome.runtime.sendMessage({ type: 'SET_SESSION_ALARM', endsAt });
    } else if (!on) {
      if (state.cooldownEnabled && state.focusSession) {
        state.cooldownUntil = Date.now() + state.cooldownMinutes * 60000;
      }
      state.focusSession = null;
      chrome.runtime.sendMessage({ type: 'CLEAR_SESSION_ALARM' });
    }
    saveState(); renderAll(); startCountdown();
    toast(on ? 'Blocking active' : 'Blocking off');
  }

  // Preset duration
  document.querySelectorAll('.duration-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.duration-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.selectedMinutes = parseInt(btn.dataset.min);
      document.getElementById('customMinutes').value = '';
    });
  });

  // Custom minutes — validate: integer only, 1–1440
  document.getElementById('customMinutes').addEventListener('input', (e) => {
    const raw   = e.target.value;
    const errEl = document.getElementById('customMinError');

    // Reject decimals
    if (raw.includes('.')) {
      errEl.textContent = 'Please enter whole minutes only — no decimals.';
      errEl.style.display = 'block';
      return;
    }

    const val = parseInt(raw, 10);

    if (raw === '' || isNaN(val)) {
      errEl.style.display = 'none';
      return;
    }

    if (val <= 0) {
      errEl.textContent = 'Minutes must be at least 1.';
      errEl.style.display = 'block';
      return;
    }

    if (val > 1440) {
      errEl.textContent = 'Maximum is 1440 minutes (24 hours).';
      errEl.style.display = 'block';
      // Clamp the field visually
      e.target.value = 1440;
      state.selectedMinutes = 1440;
      document.querySelectorAll('.duration-btn').forEach(b => b.classList.remove('active'));
      return;
    }

    // Valid
    errEl.style.display = 'none';
    state.selectedMinutes = val;
    document.querySelectorAll('.duration-btn').forEach(b => b.classList.remove('active'));
  });

  // Pause
  document.getElementById('pauseBtn').addEventListener('click', () => {
    if (!state.focusSession) return;
    if (state.focusSession.paused) {
      state.focusSession.endsAt = Date.now() + state.focusSession.remainingMs;
      state.focusSession.paused = false;
      state.focusSession.remainingMs = null;
      chrome.runtime.sendMessage({ type: 'SET_SESSION_ALARM', endsAt: state.focusSession.endsAt });
    } else {
      state.focusSession.remainingMs = Math.max(0, state.focusSession.endsAt - Date.now());
      state.focusSession.paused = true;
      chrome.runtime.sendMessage({ type: 'CLEAR_SESSION_ALARM' });
    }
    saveState(); renderAll(); startCountdown();
  });

  // Reset session
  document.getElementById('resetBtn').addEventListener('click', () => {
    if (!state.focusSession) return;
    const endsAt = Date.now() + state.selectedMinutes * 60 * 1000;
    state.focusSession = { endsAt, paused: false };
    chrome.runtime.sendMessage({ type: 'SET_SESSION_ALARM', endsAt });
    saveState(); renderAll(); startCountdown();
    toast('Session reset');
  });

  // Strict mode
  document.getElementById('strictToggle').addEventListener('change', (e) => {
    state.strictMode = e.target.checked;
    saveState(false); renderHeader();
  });

  // Cooldown toggle
  document.getElementById('cooldownToggle').addEventListener('change', (e) => {
    state.cooldownEnabled = e.target.checked;
    document.getElementById('cooldownMinRow').style.display = e.target.checked ? 'flex' : 'none';
    saveState(false);
  });

  document.getElementById('cooldownMinInput').addEventListener('change', (e) => {
    state.cooldownMinutes = Math.max(1, parseInt(e.target.value) || 5);
    saveState(false);
  });

  // Add site
  document.getElementById('addBtn').addEventListener('click', addSite);
  document.getElementById('addInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') addSite(); });

  // Block current tab

  // Export
  document.getElementById('exportBtn').addEventListener('click', () => {
    const data = JSON.stringify({ blocklist: state.blocklist }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'focus-blocker-export.json'; a.click();
    URL.revokeObjectURL(url);
    toast('Exported');
  });

  // Import
  document.getElementById('importBtn').addEventListener('click', () => document.getElementById('importFile').click());
  document.getElementById('importFile').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const parsed = JSON.parse(ev.target.result);
        if (parsed.blocklist && Array.isArray(parsed.blocklist)) {
          const newEntries = parsed.blocklist.map(b => typeof b === 'string' ? { domain: b, categories: [] } : b);
          let added = 0;
          newEntries.forEach(entry => {
            if (!state.blocklist.find(b => b.domain === entry.domain)) {
              state.blocklist.push(entry); added++;
            }
          });
          saveState(); renderBlocklist();
          toast(`Imported ${added} sites`);
        }
      } catch { toast('Invalid file'); }
    };
    reader.readAsText(file);
    e.target.value = '';
  });

  // Schedule
  document.getElementById('scheduleToggle').addEventListener('change', (e) => {
    state.schedule.enabled = e.target.checked;
    updateScheduleBadge(e.target.checked);
    saveState(false);
    chrome.runtime.sendMessage({ type: 'SCHEDULE_UPDATED' });
    toast(e.target.checked ? 'Auto-schedule enabled' : 'Auto-schedule disabled');
  });
  document.querySelectorAll('.day-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const day = parseInt(btn.dataset.day);
      const idx = state.schedule.days.indexOf(day);
      if (idx >= 0) state.schedule.days.splice(idx, 1);
      else state.schedule.days.push(day);
      btn.classList.toggle('active');
      saveState(false);
      chrome.runtime.sendMessage({ type: 'SCHEDULE_UPDATED' });
    });
  });
  document.getElementById('scheduleStart').addEventListener('input', () => {
    startClockTicker(
      document.getElementById('scheduleStart').value || '09:00',
      document.getElementById('scheduleEnd').value   || '17:00'
    );
  });
  document.getElementById('scheduleEnd').addEventListener('input', () => {
    startClockTicker(
      document.getElementById('scheduleStart').value || '09:00',
      document.getElementById('scheduleEnd').value   || '17:00'
    );
  });
  document.getElementById('saveScheduleBtn').addEventListener('click', () => {
    state.schedule.startTime = document.getElementById('scheduleStart').value;
    state.schedule.endTime   = document.getElementById('scheduleEnd').value;
    saveState(false);
    chrome.runtime.sendMessage({ type: 'SCHEDULE_UPDATED' });
    toast('Schedule saved');
  });

  // Password
  document.getElementById('passwordToggle').addEventListener('change', (e) => {
    if (state.enabled) {
      e.target.checked = state.passwordEnabled; // revert
      toast('Turn off the blocker to change password settings');
      return;
    }
    state.passwordEnabled = e.target.checked;
    saveState(false);
  });
  document.getElementById('savePasswordBtn').addEventListener('click', () => {
    if (state.enabled) { toast('Turn off the blocker to change password'); return; }
    const pw = document.getElementById('passwordInput').value;
    if (!pw) { toast('Enter a password first'); return; }
    state.passwordHash = btoa(pw); // simple encoding
    state.passwordEnabled = true;
    document.getElementById('passwordToggle').checked = true;
    document.getElementById('passwordInput').value = '';
    saveState(false);
    toast('Password set');
  });

  // Redirect URL
  document.getElementById('saveRedirectBtn').addEventListener('click', () => {
    state.redirectUrl = document.getElementById('redirectInput').value.trim();
    saveState();
    toast('Redirect saved');
  });

  // Stats
  document.getElementById('resetStatsBtn').addEventListener('click', () => {
    state.blockAttempts = 0;
    state.siteTime = {};
    chrome.storage.local.set({ blockAttempts: 0 });
    document.getElementById('attemptsBadge').textContent = '';
    renderStats();
    toast('Stats reset');
  });

  // Reset all
  document.getElementById('resetAllBtn').addEventListener('click', () => {
    if (confirm('Reset everything to defaults?')) {
      chrome.storage.local.clear(() => location.reload());
    }
  });

  bindCatManager();
  bindSiteEdit();

  // List picker modal
  document.getElementById('listPickerSkip').addEventListener('click', () => {
    commitAddSite();
  });
  document.getElementById('listPickerConfirm').addEventListener('click', () => {
    commitAddSite();
  });
  document.getElementById('listPickerCancel').addEventListener('click', () => {
    pendingDomain = null;
    selectedCategories = [];
    document.getElementById('listPickerModal').classList.remove('show');
  });

  // Password modal
  document.getElementById('modalCancel').addEventListener('click', () => {
    hidePasswordModal(); pendingToggleAction = null;
    document.getElementById('masterToggle').checked = state.enabled;
  });
  document.getElementById('modalConfirm').addEventListener('click', checkPassword);
  document.getElementById('modalPasswordInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') checkPassword();
  });
}

function renderInlineNewList() {
  const area = document.getElementById('inlineNewList');
  if (!area) return;
  area.innerHTML = '';
  const row = document.createElement('div');
  row.style.cssText = 'display:flex;gap:6px;align-items:center;margin-top:4px;';
  row.innerHTML = `
    <input id="inlineListName" type="text" placeholder="New list name..." style="flex:1;background:#fff;border:2px solid var(--border);color:var(--text);font-family:inherit;font-size:13px;font-weight:500;padding:5px 8px;border-radius:6px;outline:none;">
    <input id="inlineListColor" type="color" value="#DA7756" style="width:32px;height:32px;border:2px solid var(--border);border-radius:6px;cursor:pointer;padding:2px;background:var(--surface);">
    <button id="inlineListAdd" style="background:var(--accent);color:#fff;border:none;font-family:inherit;font-size:12px;font-weight:800;padding:6px 10px;cursor:pointer;border-radius:6px;">+ List</button>`;
  area.appendChild(row);
  area.querySelector('#inlineListAdd').addEventListener('click', () => {
    const name  = area.querySelector('#inlineListName').value.trim();
    const color = area.querySelector('#inlineListColor').value;
    if (!name) { toast('Enter a list name'); return; }
    if (CATEGORIES[name]) { toast('List already exists'); return; }
    CATEGORIES[name] = color;
    state.customCategories[name] = color;
    delete state.deletedCategories[name];
    selectedCategories.push(name);
    saveState(false);
    renderTagPicker();
    renderInlineNewList();
    area.querySelector('#inlineListName').value = '';
    toast(`List "${name}" created`);
  });
  area.querySelector('#inlineListName').addEventListener('keydown', e => {
    if (e.key === 'Enter') area.querySelector('#inlineListAdd').click();
  });
}

let pendingDomain = null;

function addSite() {
  const input = document.getElementById('addInput');
  let raw = input.value.trim();
  let allowedPath = '';
  if (raw.includes('|')) {
    const parts = raw.split('|');
    raw = parts[0].trim();
    allowedPath = parts[1].trim();
  }
  let domain = raw.replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/$/, '').toLowerCase();
  if (!domain) { toast('Enter a domain first'); return; }
  const fullDomain = allowedPath ? `${domain}|${allowedPath}` : domain;
  if (state.blocklist.find(b => b.domain === fullDomain)) { toast('Already in blocklist'); return; }
  pendingDomain = fullDomain;
  openListPickerModal(domain);
}

function openListPickerModal(displayDomain) {
  const modal = document.getElementById('listPickerModal');
  document.getElementById('listPickerDomain').textContent = displayDomain;
  // Reset selections
  selectedCategories = [];
  renderListPickerTags();
  renderListPickerNewList();
  modal.classList.add('show');
}

function renderListPickerTags() {
  const container = document.getElementById('listPickerTags');
  container.innerHTML = Object.entries(CATEGORIES).map(([name, color]) => {
    const isSel = selectedCategories.includes(name);
    const bg    = isSel ? color : color + '18';
    const col   = isSel ? '#fff' : color;
    const bord  = isSel ? 'transparent' : color;
    return `<button class="tag-option${isSel ? ' selected' : ''}" data-cat="${escHtml(name)}"
      style="background:${bg};color:${col};border-color:${bord};">${escHtml(name)}</button>`;
  }).join('') || '<span style="color:var(--muted);font-size:13px;">No lists yet — create one below.</span>';

  container.querySelectorAll('.tag-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.dataset.cat;
      const idx = selectedCategories.indexOf(cat);
      if (idx >= 0) selectedCategories.splice(idx, 1); else selectedCategories.push(cat);
      renderListPickerTags();
    });
  });
}

function renderListPickerNewList() {
  const area = document.getElementById('listPickerNewListArea');
  area.innerHTML = '';
  const row = document.createElement('div');
  row.style.cssText = 'display:flex;gap:6px;align-items:center;';
  row.innerHTML = `
    <input id="lpListName" type="text" placeholder="New list name..." style="flex:1;background:var(--bg);border:2px solid var(--border);color:var(--text);font-family:inherit;font-size:13px;font-weight:500;padding:6px 9px;border-radius:6px;outline:none;">
    <input id="lpListColor" type="color" value="#DA7756" style="width:34px;height:34px;border:2px solid var(--border);border-radius:6px;cursor:pointer;padding:2px;background:var(--surface);">
    <button id="lpListAdd" style="background:var(--accent);color:#fff;border:none;font-family:inherit;font-size:12px;font-weight:800;padding:6px 11px;cursor:pointer;border-radius:6px;white-space:nowrap;">+ List</button>`;
  area.appendChild(row);
  row.querySelector('#lpListAdd').addEventListener('click', () => {
    const name  = row.querySelector('#lpListName').value.trim();
    const color = row.querySelector('#lpListColor').value;
    if (!name) { toast('Enter a list name'); return; }
    if (CATEGORIES[name]) { toast('List already exists'); return; }
    CATEGORIES[name] = color;
    state.customCategories[name] = color;
    delete state.deletedCategories[name];
    selectedCategories.push(name);
    saveState(false);
    renderListPickerTags();
    renderBlocklist();
    row.querySelector('#lpListName').value = '';
    toast(`List "${name}" created`);
  });
  row.querySelector('#lpListName').addEventListener('keydown', e => {
    if (e.key === 'Enter') row.querySelector('#lpListAdd').click();
  });
}

function commitAddSite() {
  if (!pendingDomain) return;
  state.blocklist.push({ domain: pendingDomain, categories: [...selectedCategories] });
  const display = pendingDomain.split('|')[0];
  pendingDomain = null;
  selectedCategories = [];
  document.getElementById('addInput').value = '';
  document.getElementById('listPickerModal').classList.remove('show');
  saveState(); renderBlocklist();
  toast(`Added ${display}`);
}

// ── Countdown ─────────────────────────────────────────────────────────────────
function startCountdown() {
  clearInterval(countdownInterval);
  const el = document.getElementById('sessionCountdown');
  if (!state.enabled) { el.textContent = ''; return; }
  if (!state.focusSession || !state.focusSession.endsAt) { el.textContent = 'No time limit set'; return; }
  if (state.focusSession.paused) {
    const r = state.focusSession.remainingMs || 0;
    el.textContent = `Paused — ${fmt(r)} left`; return;
  }
  function tick() {
    const rem = Math.max(0, state.focusSession.endsAt - Date.now());
    if (rem <= 0) {
      el.textContent = 'Session complete ✓';
      clearInterval(countdownInterval);
      if (state.cooldownEnabled) state.cooldownUntil = Date.now() + state.cooldownMinutes * 60000;
      state.enabled = false; state.focusSession = null;
      saveState(); renderAll(); return;
    }
    el.textContent = `${fmt(rem)} remaining`;
  }
  tick();
  countdownInterval = setInterval(tick, 1000);
}

function fmt(ms) {
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return `${m}:${String(s).padStart(2,'0')}`;
}


function loadAttempts() {
  chrome.runtime.sendMessage({ type: 'GET_BLOCK_ATTEMPTS' }, (res) => {
    if (res) {
      state.blockAttempts = res.count;
      if (res.count > 0) {
        document.getElementById('attemptsBadge').innerHTML = `Blocked <span>${res.count}×</span> today`;
      }
    }
  });
}

// ── Password modal ────────────────────────────────────────────────────────────
function showPasswordModal() {
  document.getElementById('passwordModal').classList.add('show');
  document.getElementById('modalPasswordInput').value = '';
  document.getElementById('modalError').textContent = '';
  setTimeout(() => document.getElementById('modalPasswordInput').focus(), 50);
}

function hidePasswordModal() {
  document.getElementById('passwordModal').classList.remove('show');
}

function checkPassword() {
  const input = document.getElementById('modalPasswordInput').value;
  if (btoa(input) === state.passwordHash) {
    hidePasswordModal();
    if (pendingToggleAction) { pendingToggleAction(); pendingToggleAction = null; }
  } else {
    document.getElementById('modalError').textContent = 'Incorrect password';
    document.getElementById('modalPasswordInput').value = '';
  }
}

// ── Site List Editor ─────────────────────────────────────────────────────────
let editingIndex = null;

function openSiteEdit(idx) {
  editingIndex = idx;
  const entry = state.blocklist[idx];
  let domain = entry.domain;
  if (domain.includes('|')) domain = domain.split('|')[0];
  document.getElementById('siteEditTitle').textContent = domain;

  const currentCats = getCats(entry);
  const tagsEl = document.getElementById('siteEditTags');
  tagsEl.innerHTML = Object.entries(CATEGORIES).map(([name, color]) => {
    const active = currentCats.includes(name);
    return `<button class="tag-option${active ? ' selected' : ''}" data-cat="${escHtml(name)}"
      style="${active ? `background:${color};color:#fff;border-color:transparent;` : `border-color:${color};color:${color};background:${color}15;`}">
      ${escHtml(name)}</button>`;
  }).join('');

  tagsEl.querySelectorAll('.tag-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.dataset.cat;
      const cats = getCats(state.blocklist[editingIndex]);
      const i = cats.indexOf(cat);
      if (i >= 0) cats.splice(i, 1); else cats.push(cat);
      state.blocklist[editingIndex].categories = cats;
      delete state.blocklist[editingIndex].category;
      saveState(false);
      // Re-render tags in modal
      openSiteEdit(editingIndex);
    });
  });

  document.getElementById('siteEditOverlay').classList.add('show');
}

function bindSiteEdit() {
  document.getElementById('siteEditDone').addEventListener('click', () => {
    document.getElementById('siteEditOverlay').classList.remove('show');
    renderBlocklist();
  });
  document.getElementById('siteEditRemove').addEventListener('click', () => {
    if (editingIndex === null) return;
    const domain = state.blocklist[editingIndex].domain.split('|')[0];
    if (!confirm(`Remove "${domain}" from your blocklist?`)) return;
    state.blocklist.splice(editingIndex, 1);
    saveState();
    renderBlocklist();
    document.getElementById('siteEditOverlay').classList.remove('show');
    toast(`Removed ${domain}`);
  });
}

// ── Category Manager ─────────────────────────────────────────────────────────
function openCatManager() {
  document.getElementById('catPanel').classList.add('open');
  renderCatManager();
}

function closeCatManager() {
  document.getElementById('catPanel').classList.remove('open');
}

function purgeExpiredDeletedLists() {
  const EXPIRY_MS = 48 * 60 * 60 * 1000;
  const now = Date.now();
  let changed = false;
  Object.keys(state.deletedCategories).forEach(cat => {
    const entry = state.deletedCategories[cat];
    // entry is either a color string (legacy) or { color, deletedAt }
    const deletedAt = typeof entry === 'object' ? entry.deletedAt : null;
    if (deletedAt && now - deletedAt > EXPIRY_MS) {
      delete state.deletedCategories[cat];
      changed = true;
    }
  });
  if (changed) saveState();
}

function getDeletedColor(entry) {
  return typeof entry === 'object' ? entry.color : entry;
}

function getDeletedAt(entry) {
  return typeof entry === 'object' ? entry.deletedAt : null;
}

function renderCatManager() {
  purgeExpiredDeletedLists();

  const activeList     = document.getElementById('activeCatList');
  const deletedList    = document.getElementById('deletedCatList');
  const deletedSection = document.getElementById('deletedCatSection');

  // Count sites per list
  const counts = {};
  state.blocklist.forEach(entry => {
    getCats(entry).forEach(c => { counts[c] = (counts[c] || 0) + 1; });
  });

  // ── Active lists ──────────────────────────────────────────────────────────
  activeList.innerHTML = Object.entries(CATEGORIES).map(([name, color]) => {
    const count = counts[name] || 0;
    return `<div class="cat-row">
      <div class="cat-row-left">
        <div class="cat-row-dot" style="background:${color}"></div>
        <span class="cat-row-name">${escHtml(name)}</span>
        <span class="cat-row-count">${count} site${count !== 1 ? 's' : ''}</span>
      </div>
      <div class="cat-row-actions">
        <button class="cat-del-btn" data-cat="${escHtml(name)}">Delete</button>
      </div>
    </div>`;
  }).join('') || '<div style="color:var(--muted);font-size:13px;padding:8px 0;">No active lists.</div>';

  activeList.querySelectorAll('.cat-del-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.dataset.cat;
      const color = CATEGORIES[cat];
      state.deletedCategories[cat] = { color, deletedAt: Date.now() };
      delete CATEGORIES[cat];
      delete state.customCategories[cat];
      state.blocklist.forEach(entry => {
        const cats = getCats(entry);
        const idx = cats.indexOf(cat);
        if (idx >= 0) { cats.splice(idx, 1); entry.categories = cats; delete entry.category; }
      });
      const si = selectedCategories.indexOf(cat);
      if (si >= 0) selectedCategories.splice(si, 1);
      if (activeCategory === cat) activeCategory = 'All';
      saveState();
      renderCatManager();
      renderBlocklist();
      toast(`List "${cat}" deleted`);
    });
  });

  // ── Deleted lists ─────────────────────────────────────────────────────────
  const deletedEntries = Object.entries(state.deletedCategories);
  if (deletedEntries.length > 0) {
    deletedSection.style.display = 'block';

    deletedList.innerHTML = deletedEntries.map(([name, entry]) => {
      const color     = getDeletedColor(entry);
      const deletedAt = getDeletedAt(entry);
      const expiresIn = deletedAt
        ? Math.max(0, Math.ceil((deletedAt + 48*3600000 - Date.now()) / 3600000))
        : null;
      const expiry = expiresIn !== null
        ? `<span style="font-size:11px;color:var(--muted);margin-left:6px;">expires in ${expiresIn}h</span>`
        : '';
      return `<div class="cat-row cat-deleted-row" style="opacity:0.8;">
        <div class="cat-row-left" style="flex:1;min-width:0;">
          <div class="cat-row-dot" style="background:${color}"></div>
          <span class="cat-row-name">${escHtml(name)}</span>
          ${expiry}
        </div>
        <div class="cat-row-actions" style="gap:5px;">
          <button class="cat-restore-btn" data-cat="${escHtml(name)}">Restore</button>
          <button class="cat-perm-del-btn" data-cat="${escHtml(name)}">Delete Forever</button>
        </div>
      </div>`;
    }).join('');

    // Restore buttons
    deletedList.querySelectorAll('.cat-restore-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const cat   = btn.dataset.cat;
        const entry = state.deletedCategories[cat];
        const color = getDeletedColor(entry);
        CATEGORIES[cat] = color;
        state.customCategories[cat] = color;
        delete state.deletedCategories[cat];
        saveState();
        renderCatManager();
        renderBlocklist();
        toast(`List "${cat}" restored`);
      });
    });

    // Delete Forever buttons
    deletedList.querySelectorAll('.cat-perm-del-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const cat = btn.dataset.cat;
        if (!confirm(`Permanently delete the list "${cat}"?\n\nThis cannot be undone.`)) return;
        delete state.deletedCategories[cat];
        saveState();
        renderCatManager();
        toast(`List "${cat}" permanently deleted`);
      });
    });

    // Clear All button — bound fresh each render since element may re-appear
    const clearBtn = document.getElementById('clearAllDeletedBtn');
    if (clearBtn) {
      // Clone to remove any stale listener
      const fresh = clearBtn.cloneNode(true);
      clearBtn.parentNode.replaceChild(fresh, clearBtn);
      fresh.addEventListener('click', () => {
        if (!confirm('Permanently delete ALL lists in the trash?\n\nThis cannot be undone.')) return;
        state.deletedCategories = {};
        saveState();
        renderCatManager();
        toast('Trash cleared');
      });
    }

  } else {
    deletedSection.style.display = 'none';
  }
}

function bindCatManager() {
  document.getElementById('openCatManager').addEventListener('click', openCatManager);
  document.getElementById('closeCatPanel').addEventListener('click', closeCatManager);

  document.getElementById('catPanelAddBtn').addEventListener('click', () => {
    const name  = document.getElementById('catPanelNameInput').value.trim();
    const color = document.getElementById('catPanelColor').value;
    if (!name) { toast('Enter a list name'); return; }
    if (CATEGORIES[name]) { toast('List already exists'); return; }
    CATEGORIES[name] = color;
    state.customCategories[name] = color;
    // Also un-delete if it was previously deleted
    delete state.deletedCategories[name];
    document.getElementById('catPanelNameInput').value = '';
    saveState();
    renderCatManager();
    renderBlocklist();
    toast(`List "${name}" added`);
  });
  document.getElementById('catPanelNameInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') document.getElementById('catPanelAddBtn').click();
  });
}

// ── Utilities ─────────────────────────────────────────────────────────────────
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 1800);
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
