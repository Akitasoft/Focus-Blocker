// contentscript.js

const BLOCKED_PAGE = chrome.runtime.getURL('blocked.html');

function checkAndBlock() {
  if (location.href.startsWith(BLOCKED_PAGE)) return;
  chrome.storage.local.get(['blocklist', 'enabled', 'redirectUrl', 'activeLists'], (data) => {
    if (!data.enabled || !data.blocklist || !data.blocklist.length) return;
    const hostname = location.hostname.replace(/^www\./, '');
    const blocklist = data.blocklist.map(b => typeof b === 'string' ? { domain: b } : b);
    const useAll = !data.activeLists || data.activeLists.length === 0;
    const match = blocklist.find(entry => {
      let domain = entry.domain;
      let allowedPath = null;
      if (domain.includes('|')) [domain, allowedPath] = domain.split('|');
      domain = domain.replace(/^www\./, '');
      const domainMatch = hostname === domain || hostname.endsWith('.' + domain);
      if (!domainMatch) return false;
      if (allowedPath && location.pathname.startsWith(allowedPath)) return false;
      if (!useAll) {
        const cats = Array.isArray(entry.categories) ? entry.categories : (entry.category ? [entry.category] : []);
        if (cats.length > 0 && !cats.some(c => data.activeLists.includes(c))) return false;
      }
      return true;
    });
    if (match) {
      const target = (data.redirectUrl && data.redirectUrl.trim()) ? data.redirectUrl.trim() : BLOCKED_PAGE;
      const encodedSrc = encodeURIComponent(location.href);
      const dest = target.includes('blocked.html') ? target + '?src=' + encodedSrc : target;
      location.replace(dest);
    }
  });
}

checkAndBlock();

const _pushState = history.pushState.bind(history);
const _replaceState = history.replaceState.bind(history);
history.pushState = function(...args) { _pushState(...args); checkAndBlock(); };
history.replaceState = function(...args) { _replaceState(...args); checkAndBlock(); };
window.addEventListener('popstate', checkAndBlock);
