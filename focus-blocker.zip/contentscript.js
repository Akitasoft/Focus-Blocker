// contentscript.js

const BLOCKED_PAGE = chrome.runtime.getURL('blocked.html');

function checkAndBlock() {
  if (location.href.startsWith(BLOCKED_PAGE)) return;
  chrome.storage.local.get(['blocklist', 'enabled', 'redirectUrl', 'activeLists'], (data) => {
    if (!data.enabled || !data.blocklist || !data.blocklist.length) return;
    const hostname = location.hostname.replace(/^www\./, '');
    const blocklist = data.blocklist.map(b => typeof b === 'string' ? { domain: b } : b);
    const useAll = data.activeLists && data.activeLists.includes('__ALL__');
    const noneSelected = !data.activeLists || data.activeLists.length === 0;
    const match = blocklist.find(entry => {
      let domain = entry.domain;
      let allowedPath = null;
      if (domain.includes('|')) [domain, allowedPath] = domain.split('|');
      domain = domain.replace(/^www\./, '');
      if (hostname !== domain && !hostname.endsWith('.' + domain)) return false;
      if (allowedPath && location.pathname.startsWith(allowedPath)) return false;
      if (noneSelected) return false;
      if (!useAll) {
        const cats = Array.isArray(entry.categories) ? entry.categories : (entry.category ? [entry.category] : []);
        if (cats.length > 0 && !cats.some(c => data.activeLists.includes(c))) return false;
      }
      return true;
    });
    if (match) {
      location.replace(BLOCKED_PAGE + '?src=' + encodeURIComponent(location.href));
    }
  });
}

checkAndBlock();

const _push    = history.pushState.bind(history);
const _replace = history.replaceState.bind(history);
history.pushState    = function(...a) { _push(...a);    checkAndBlock(); };
history.replaceState = function(...a) { _replace(...a); checkAndBlock(); };
window.addEventListener('popstate', checkAndBlock);
