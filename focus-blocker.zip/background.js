// background.js — Focus Blocker background service worker

const BLOCKED_URL = () => chrome.runtime.getURL('blocked.html');

// ── Install defaults ──────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    blocklist: [
      { domain: 'reddit.com', categories: ['Social'] },
      { domain: 'twitter.com', categories: ['Social'] },
      { domain: 'x.com', categories: ['Social'] },
      { domain: 'facebook.com', categories: ['Social'] },
      { domain: 'instagram.com', categories: ['Social'] },
      { domain: 'tiktok.com', categories: ['Social'] },
      { domain: 'youtube.com', categories: ['Entertainment'] },
    ],
    enabled: false,
    focusSession: null,
    strictMode: false,
    passwordHash: null,
    cooldownUntil: null,
    cooldownMinutes: 5,
    schedule: { enabled: false, days: [1,2,3,4,5], startTime: '09:00', endTime: '17:00' },
    redirectUrl: '',
    blockAttempts: 0,
    quotes: [],
  });
});

// Purge deleted lists older than 48 hours on startup
chrome.storage.local.get('deletedCategories', (data) => {
  const deleted = data.deletedCategories || {};
  const EXPIRY_MS = 48 * 60 * 60 * 1000;
  const now = Date.now();
  let changed = false;
  Object.keys(deleted).forEach(cat => {
    const entry = deleted[cat];
    const deletedAt = typeof entry === 'object' ? entry.deletedAt : null;
    if (deletedAt && now - deletedAt > EXPIRY_MS) {
      delete deleted[cat];
      changed = true;
    }
  });
  if (changed) chrome.storage.local.set({ deletedCategories: deleted });
});

// Rebuild rules on service worker startup
chrome.storage.local.get(null, (data) => {
  checkSchedule(data);
  _doRebuild(
    (data.blocklist || []).map(b => typeof b === 'string' ? { domain: b, categories: [] } : b),
    data.enabled || false,
    data.redirectUrl || '',
    data.activeLists || []
  );
});

// ── Rule building ─────────────────────────────────────────────────────────────
function getEntryCats(entry) {
  if (Array.isArray(entry.categories) && entry.categories.length > 0) return entry.categories;
  if (entry.category) return [entry.category];
  return [];
}

function _doRebuild(_blocklist, _enabled, _redirectUrl, _activeLists) {
  // All blocking is handled by webNavigation listeners.
  // declarativeNetRequest is not used (removed from manifest).
}

// ── Schedule checker ──────────────────────────────────────────────────────────
function checkSchedule(data) {
  if (!data || !data.schedule || !data.schedule.enabled) return;
  const now     = new Date();
  const day     = now.getDay();
  const h       = now.getHours().toString().padStart(2,'0');
  const m       = now.getMinutes().toString().padStart(2,'0');
  const timeStr = h + ':' + m;

  const inSchedule = data.schedule.days.includes(day) &&
    timeStr >= data.schedule.startTime &&
    timeStr <  data.schedule.endTime;

  if (inSchedule && !data.enabled) {
    chrome.storage.local.set({ enabled: true }, () => {
      checkOpenTabs();
    });
  } else if (!inSchedule && data.enabled) {
    chrome.storage.local.set({ enabled: false });
  }
}

// Check schedule every minute (guard against duplicate alarms on restart)
chrome.alarms.get('scheduleCheck', (existing) => {
  if (!existing) chrome.alarms.create('scheduleCheck', { periodInMinutes: 1 });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'scheduleCheck') {
    chrome.storage.local.get(null, (data) => {
      checkSchedule(data);
      // Purge expired deleted lists hourly
      const deleted = data.deletedCategories || {};
      const EXPIRY_MS = 48 * 60 * 60 * 1000;
      const now = Date.now();
      let changed = false;
      Object.keys(deleted).forEach(cat => {
        const entry = deleted[cat];
        const deletedAt = typeof entry === 'object' ? entry.deletedAt : null;
        if (deletedAt && now - deletedAt > EXPIRY_MS) { delete deleted[cat]; changed = true; }
      });
      if (changed) chrome.storage.local.set({ deletedCategories: deleted });
    });
  }
  if (alarm.name === 'sessionEnd') {
    chrome.storage.local.get(['blocklist', 'redirectUrl', 'cooldownMinutes', 'cooldownEnabled'], (data) => {
      const cooldownUntil = data.cooldownEnabled
        ? Date.now() + (data.cooldownMinutes || 5) * 60000
        : null;
      chrome.storage.local.set({ enabled: false, focusSession: null, cooldownUntil });
      _doRebuild(data.blocklist || [], false, data.redirectUrl || '', []);
    });
  }
});

// ── Navigation listeners ──────────────────────────────────────────────────────
function handleNav(details) {
  if (details.frameId !== 0) return;
  const extBase = chrome.runtime.getURL('');
  if (details.url.startsWith(extBase)) return;

  chrome.storage.local.get(null, (data) => {
    if (!data.enabled || !data.blocklist || !data.blocklist.length) return;
    try {
      const hostname = new URL(details.url).hostname.replace(/^www\./, '');
      if (!hostname) return;

      const blocklist = data.blocklist.map(b => typeof b === 'string' ? { domain: b } : b);
      const useAll = data.activeLists && data.activeLists.includes('__ALL__');
      const noneSelected = !data.activeLists || data.activeLists.length === 0;
      const match = blocklist.find(entry => {
        let domain = entry.domain;
        let allowedPath = null;
        if (domain.includes('|')) [domain, allowedPath] = domain.split('|');
        domain = domain.replace(/^www\./, '');
        const domainMatch = hostname === domain || hostname.endsWith('.' + domain);
        if (!domainMatch) return false;
        if (allowedPath) {
          const urlPath = new URL(details.url).pathname;
          if (urlPath.startsWith(allowedPath)) return false;
        }
        if (noneSelected) return false; // no lists selected — block nothing
        if (!useAll) {
          const cats = getEntryCats(entry);
          if (cats.length > 0 && !cats.some(c => data.activeLists.includes(c))) return false;
        }
        return true;
      });

      if (match) {
        // Increment block attempts
        chrome.storage.local.set({ blockAttempts: (data.blockAttempts || 0) + 1 });
        const baseTarget = (data.redirectUrl && data.redirectUrl.trim()) ? data.redirectUrl.trim() : BLOCKED_URL();
        // Pass the blocked URL as a query param so Focus Wall can display it
        const encodedSrc = encodeURIComponent(details.url);
        const target = baseTarget.includes('blocked.html')
          ? baseTarget + '?src=' + encodedSrc
          : baseTarget;
        chrome.tabs.update(details.tabId, { url: target });
      }
    } catch (e) {}
  });
}

chrome.webNavigation.onBeforeNavigate.addListener(handleNav);
chrome.webNavigation.onCommitted.addListener(handleNav);

// ── Message handler ───────────────────────────────────────────────────────────
function checkOpenTabs(passedActiveLists) {
  chrome.storage.local.get(null, (data) => {
    if (!data.enabled || !data.blocklist || !data.blocklist.length) return;
    // Use passedActiveLists when available to avoid async storage timing issues
    const activeLists  = passedActiveLists !== undefined ? passedActiveLists : (data.activeLists || []);
    const useAll       = activeLists.includes('__ALL__');
    const noneSelected = activeLists.length === 0;
    const extBase      = chrome.runtime.getURL('');

    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        if (!tab.url || tab.url.startsWith(extBase)) return;
        let hostname;
        try { hostname = new URL(tab.url).hostname.replace(/^www\./, ''); }
        catch(e) { return; }

        const blocklist = data.blocklist.map(b => typeof b === 'string' ? { domain: b } : b);
        const match = blocklist.find(entry => {
          let domain = entry.domain;
          let allowedPath = null;
          if (domain.includes('|')) [domain, allowedPath] = domain.split('|');
          domain = domain.replace(/^www\./, '');
          if (hostname !== domain && !hostname.endsWith('.' + domain)) return false;
          if (allowedPath) {
            try {
              const urlPath = new URL(tab.url).pathname;
              if (urlPath.startsWith(allowedPath)) return false;
            } catch(e) {}
          }
          if (noneSelected) return false; // no lists selected — block nothing
          if (!useAll) {
            const cats = getEntryCats(entry);
            if (cats.length > 0 && !cats.some(c => activeLists.includes(c))) return false;
          }
          return true;
        });

        if (match) {
          const baseTarget = (data.redirectUrl && data.redirectUrl.trim())
            ? data.redirectUrl.trim()
            : chrome.runtime.getURL('blocked.html');
          const encodedSrc = encodeURIComponent(tab.url);
          const target = baseTarget.includes('blocked.html')
            ? baseTarget + '?src=' + encodedSrc
            : baseTarget;
          chrome.storage.local.set({ blockAttempts: (data.blockAttempts || 0) + 1 });
          chrome.tabs.update(tab.id, { url: target });
        }
      });
    });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'REBUILD_RULES') {
    _doRebuild(msg.blocklist, msg.enabled, msg.redirectUrl || '', msg.activeLists || []);
    if (msg.enabled) checkOpenTabs(msg.activeLists || []);
  }
  if (msg.type === 'SCHEDULE_UPDATED') {
    // Run schedule check immediately when user saves schedule settings
    chrome.storage.local.get(null, (data) => {
      checkSchedule(data);
    });
  }
  if (msg.type === 'SET_SESSION_ALARM') {
    chrome.alarms.clear('sessionEnd');
    if (msg.endsAt) chrome.alarms.create('sessionEnd', { when: msg.endsAt });
  }
  if (msg.type === 'CLEAR_SESSION_ALARM') {
    chrome.alarms.clear('sessionEnd');
  }
  if (msg.type === 'GET_BLOCK_ATTEMPTS') {
    chrome.storage.local.get('blockAttempts', (d) => sendResponse({ count: d.blockAttempts || 0 }));
    return true;
  }
});
